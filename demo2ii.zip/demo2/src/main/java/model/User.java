package model;

import javax.persistence.*;

 @Entity
 @Table(name = "usercontact")
 public class User {
     @Id
     @GeneratedValue(strategy = GenerationType.IDENTITY)
     private Integer id;

     @Column(name = "firstname")
     private String firstname;

     @Column(name = "lastname")
     private String lastname;

     @Column(name = "mail")
     private String mail;

     @Column(name = "phonenumber")
     private String phoneNumber;

     // Constructors
     public User() {
     }

     public User(Integer id, String firstname, String lastname, String mail, String phoneNumber) {
         this.firstname = firstname;
         this.id = id;
         this.lastname = lastname;
         this.phoneNumber = phoneNumber;
         this.mail = mail;
     }

     public User(String firstname, String lastname, String mail, String phoneNumber) {
         this.firstname = firstname;
         this.lastname = lastname;
         this.phoneNumber = phoneNumber;
         this.mail = mail;
     }

     // Getters and Setters
     public Integer getId() {
         return id;
     }

     public void setId(Integer id) {
         this.id = id;
     }

     public String getFirstname() {
         return firstname;
     }

     public void setFirstname(String firstname) {
         this.firstname = firstname;
     }

     public String getLastname() {
         return lastname;
     }

     public void setLastname(String lastname) {
         this.lastname = lastname;
     }

     public String getMail() {
         return mail;
     }

     public void setMail(String mail) {
         this.mail = mail;
     }

     public String getPhoneNumber() {
         return phoneNumber;
     }

     public void setPhoneNumber(String phoneNumber) {
         this.phoneNumber = phoneNumber;
     }
 }
