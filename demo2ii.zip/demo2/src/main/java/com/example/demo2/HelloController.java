package com.example.demo2;

import database.UserDb;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.User;

import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.Stack;

public class HelloController implements Initializable{

    @Override
    public void initialize(URL url, ResourceBundle  rb){
        Image logo = new Image(getClass().getResourceAsStream("/gif.gif"));
        logoImageView.setImage(logo);
        showContact();
        delbtn.setDisable(true);
        modifybtn.setDisable(true);
    }

    @FXML
    private ImageView logoImageView;
    @FXML
    public TextField fieldnom;
    @FXML
    public TextField fieldprenom;
    @FXML
    public TextField fieldemail;
    @FXML
    public TextField fieldphone;
    @FXML
    public Button addbtn;
    @FXML
    public Button delbtn;
    @FXML
    public Button closebtn;
    @FXML
    public Button modifybtn;
    @FXML
    public TableView<User> tableView;
    @FXML
    public TableColumn<User,Integer> colId;
    @FXML
    public TableColumn<User,String> colNom;
    @FXML
    public TableColumn<User,String> colPrenom;
    @FXML
    public TableColumn<User,String> colEmail;
    @FXML
    public TableColumn<User,String> colNumber;
    private  User user;

    @FXML
    private void addContact() {
        User c = new User(fieldnom.getText(),fieldprenom.getText(),fieldemail.getText(),fieldphone.getText());
        UserDb udb = new UserDb();
        udb.addUser(c);
        showModal("Ajout","Ajout de "+fieldprenom.getText()+" avec succès");
        clearFields();
        showContact();
    }

    @FXML
    private void updateContact() {
        UserDb udb = new UserDb();
        User u = new User(this.user.getId(),fieldnom.getText(),fieldprenom.getText(),fieldemail.getText(),fieldphone.getText());
        udb.updateUser(u);
        showModal("Modification","Modification de "+this.user.getFirstname()+" avec succès");
        showContact();
        clearFields();
        modifybtn.setDisable(true);
        delbtn.setDisable(true);
        addbtn.setDisable(false);
    }

    @FXML
    private void deleteContact() {
        UserDb udb = new UserDb();
        User u = new User(this.user.getId(),this.user.getFirstname(),this.user.getLastname(),this.user.getMail(),this.user.getPhoneNumber());
        udb.deleteUser(this.user.getId());
        showModal("Suppression","Suppression de "+this.user.getFirstname()+" avec succès");
        showContact();
        clearFields();
        modifybtn.setDisable(true);
        delbtn.setDisable(true);
        addbtn.setDisable(false);
    }

    @FXML
    private void showContact() {
        UserDb udb = new UserDb();
        ObservableList<User>list = udb.getAllUser();
        colId.setCellValueFactory(new PropertyValueFactory<User,Integer>("id"));
        colNom.setCellValueFactory(new PropertyValueFactory<User,String>("firstname"));
        colPrenom.setCellValueFactory(new PropertyValueFactory<User,String>("lastname"));
        colEmail.setCellValueFactory(new PropertyValueFactory<User,String>("mail"));
        colNumber.setCellValueFactory(new PropertyValueFactory<User,String>("phoneNumber"));
        tableView.setItems(list);
    }

    @FXML
    public void onMouseClicked() {
        try {
            User user =tableView.getSelectionModel().getSelectedItem();
            if(user != null){
                user = new User(user.getId(), user.getFirstname(),user.getLastname(),user.getMail(),user.getPhoneNumber());
                this.user = user;
                fieldphone.setText(user.getPhoneNumber());
                fieldemail.setText(user.getMail());
                fieldprenom.setText(user.getLastname());
                fieldnom.setText(user.getFirstname());
                delbtn.setDisable(false);
                modifybtn.setDisable(false);
                addbtn.setDisable(true);
            }
        }catch (Exception E){
            E.printStackTrace();
        }
    }

    private  void clearFields(){
        fieldnom.setText("");
        fieldprenom.setText("");
        fieldemail.setText("");
        fieldphone.setText("");
    }

    private void showModal(String title,String headerText){
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.initStyle(StageStyle.UNDECORATED);
        dialog.setTitle(title);
        dialog.setHeaderText(headerText);
        dialog.initModality(Modality.APPLICATION_MODAL);
        ButtonType oK = new ButtonType("Ok",ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(oK);
        Optional<ButtonType> result = dialog.showAndWait();
    }

    @FXML
    private void onclose() {
        Stage stage = (Stage) closebtn.getScene().getWindow();
        stage.close();
    }
}

