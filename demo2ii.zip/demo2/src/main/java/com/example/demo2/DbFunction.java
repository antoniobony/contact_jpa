package com.example.demo2;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class DbFunction {
    private static EntityManagerFactory emf;

    static {
        try {
            emf = Persistence.createEntityManagerFactory("UserPU");
        } catch (Exception e) {
            System.err.println("Initial EntityManagerFactory creation failed: " + e);
            throw new ExceptionInInitializerError(e);
        }
    }

    public static EntityManagerFactory getEntityManagerFactory() {
        return emf;
    }

    public static void close() {
        if (emf != null) {
            emf.close();
        }
    }
}

